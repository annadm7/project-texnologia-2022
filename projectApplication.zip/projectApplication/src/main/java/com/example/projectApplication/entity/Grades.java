package com.example.projectApplication.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="grade")
public class Grades {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "exam")
	private int exam;
	
	@Column(name = "project")
	private int project;



	public Grades() {
		super();
	}



	public Grades(Long id, int exam, int project) {
		super();
		this.id = id;
		this.exam = exam;
		this.project = project;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public int getExam() {
		return exam;
	}



	public void setExam(int exam) {
		this.exam = exam;
	}



	public int getProject() {
		return project;
	}



	public void setProject(int project) {
		this.project = project;
	}	
	

	
}
