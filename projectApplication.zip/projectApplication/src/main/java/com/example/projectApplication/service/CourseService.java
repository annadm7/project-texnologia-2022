package com.example.projectApplication.service;

import java.util.List;

import com.example.projectApplication.entity.Course;

public interface CourseService {

	
	List<Course> findAll();
	
	public Course findCourseByInstructorLogin(Long id);
	
	public void deleteById(Long id);
	
	public Course save(Course course);
	
	public Course update(Course course);

	
	
	 
}
