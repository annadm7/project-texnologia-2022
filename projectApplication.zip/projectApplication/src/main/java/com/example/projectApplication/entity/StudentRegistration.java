package com.example.projectApplication.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_reg")
public class StudentRegistration {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "fisrt_name", nullable = false)
	private String firstName;
	
	@Column(name = "last_name", nullable = false)
	private String lastName;
	
	@Column(name = "year_of_registration")
	private int yearOfRegistration;
	
	@Column(name = "semester")
	private int semester;
	
	public StudentRegistration() {
		
	}

	public StudentRegistration(String firstName, String lastName, int yearOfRegistration, int semester) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.yearOfRegistration = yearOfRegistration;
		this.semester = semester;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getYearOfRegistration() {
		return yearOfRegistration;
	}

	public void setYearOfRegistration(int yearOfRegistration) {
		this.yearOfRegistration = yearOfRegistration;
	}

	public int getSemester() {
		return semester;
	}

	public void setSemester(int semester) {
		this.semester = semester;
	}

	@Override
	public String toString() {
		return "StudentRegistration [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", yearOfRegistration=" + yearOfRegistration + ", semester=" + semester + "]";
	}
	
	
	
}
