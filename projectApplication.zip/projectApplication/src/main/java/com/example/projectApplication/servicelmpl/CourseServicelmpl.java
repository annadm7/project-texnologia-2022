package com.example.projectApplication.servicelmpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.projectApplication.dao.CourseDAO;
import com.example.projectApplication.entity.Course;
import com.example.projectApplication.service.CourseService;
@Service
public class CourseServicelmpl implements CourseService {
	
	private CourseDAO courseDAO;

	public CourseServicelmpl(CourseDAO courseDAO) {
		super();
		this.courseDAO = courseDAO;
	}



	@Override
	@Transactional
	public List<Course> findAll() {
		return courseDAO.findAll();
	}



	@Override
	@Transactional
	public Course findCourseByInstructorLogin(Long id) {
	
		return courseDAO.getById(id);
	}



	@Override
	@Transactional
	public void deleteById(Long id) {
		courseDAO.deleteById(id);
		
	}



	@Override
	@Transactional
	public Course save(Course course) {
		
		return courseDAO.save(course);
	}



	@Override
	@Transactional
	public Course update(Course course) {
	
		return courseDAO.save(course);
	}



	



}
