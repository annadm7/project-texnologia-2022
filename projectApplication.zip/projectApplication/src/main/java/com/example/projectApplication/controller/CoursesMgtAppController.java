package com.example.projectApplication.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.projectApplication.dao.GradeDAO;
import com.example.projectApplication.dao.InstructorDAO;
import com.example.projectApplication.entity.Course;
import com.example.projectApplication.entity.Grades;
import com.example.projectApplication.entity.Instructor;
import com.example.projectApplication.entity.StudentRegistration;
import com.example.projectApplication.service.CourseService;
import com.example.projectApplication.service.StudentRegistrationService;

@Controller

public class CoursesMgtAppController {
	
	private InstructorDAO repo;
	private CourseService courseService;
	private StudentRegistrationService studentRegService;
	private GradeDAO grades;


	public CoursesMgtAppController(InstructorDAO repo, CourseService courseService,
			StudentRegistrationService studentRegService, GradeDAO grades) {
		super();
		this.repo = repo;
		this.courseService = courseService;
		this.studentRegService = studentRegService;
		this.grades= grades;
	}
	
	// HOME PAGE
	@GetMapping("/")
	public String homePage() {
		return "home";
	}

	//LOGIN
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	//REGISTER
	 
	@GetMapping("/register")
	public String register(Model theModel) {
		theModel.addAttribute("instructor", new Instructor() );
		return "register";
	}
	
	@PostMapping("/register_save")  
	public String saveRegister( @ModelAttribute("instructor") Instructor instr) {
		Instructor newInstr = new Instructor(instr.getFirstName(), instr.getLastName(),
				instr.getEmail(), instr.getPassword()); 
		repo.save(newInstr);
		return "login";
		
	}
	// COURSES
	@GetMapping("/courses")
	public String listCourse(Model theModel) {
		theModel.addAttribute("courses", courseService.findAll());
		return "courses";
		
	}
	@GetMapping("/courses/new")
	public String addCourse(Model theModel) {
		Course theCourse = new Course();
		theModel.addAttribute("course", theCourse);
		return "add_course";
		
	}
	
	@PostMapping("/courses")
	public String saveCourse(@ModelAttribute("course") Course theCourse, Model theModel) {
		courseService.save(theCourse);
		return "redirect:/courses";
	}
	


	@GetMapping("/courses/edit/{id}")
	public String editCourse(@PathVariable Long id, Model theModel) {
		theModel.addAttribute("course", courseService.findCourseByInstructorLogin(id));
		return "edit_course";
		
	}
	
	
	@PostMapping("/courses/{id}")
	public String updateCourse(@PathVariable Long id,
			@ModelAttribute("course") Course theCourse, Model theModel) {
		
		Course theCourses = courseService.findCourseByInstructorLogin(id);
		theCourses.setId(id);
		theCourses.setName(theCourse.getName());
		theCourses.setSyllabus(theCourse.getSyllabus());
		theCourses.setYear(theCourse.getYear());
		theCourses.setSemester(theCourse.getSemester());
		
		courseService.update(theCourses);
		return "redirect:/courses";
	}
	
	
	@RequestMapping("/courses/delete/{id}")
	public String deleteCourse(@PathVariable Long id) {
		courseService.deleteById(id);
		return "redirect:/courses";
		
		
	}
	// STUDENTS
	
	@GetMapping("/students")
	public String listStudentReg(Model theModel) {
		theModel.addAttribute("students", studentRegService.findAll());
		return "students";
		
	}
	@GetMapping("/students/new")
	public String addStudentReg(Model theModel) {
		StudentRegistration theStudent = new StudentRegistration();
		theModel.addAttribute("student", theStudent);
		return "add_student";
		
	}
	
	@PostMapping("/students")
	public String saveStudentReg(@ModelAttribute("student") StudentRegistration theStudent, Model theModel) {
		studentRegService.save(theStudent);
		return "redirect:/students";
	}
	


	@GetMapping("/students/edit/{id}")
	public String editStudentReg(@PathVariable Long id, Model theModel) {
		theModel.addAttribute("student", studentRegService.findRegistrationsByCourseId(id));
		return "edit_student";
		
	}
	
	
	@PostMapping("/students/{id}")
	public String updateStudentReg(@PathVariable Long id,
			@ModelAttribute("student") StudentRegistration theStudent, Model theModel) {
		
		 StudentRegistration theStudents = studentRegService.findRegistrationsByCourseId(id);
		 theStudents.setId(id);
		 theStudents.setFirstName(theStudent.getFirstName());
		 theStudents.setLastName(theStudent.getLastName());
		 theStudents.setYearOfRegistration(theStudent.getYearOfRegistration());
		 theStudents.setSemester(theStudent.getSemester());
		
		studentRegService.update(theStudents);
		return "redirect:/students";
	}
	
	
	@RequestMapping("/students/delete/{id}")
	public String deleteStudentReg(@PathVariable Long id) {
		studentRegService.deleteById(id);
		return "redirect:/students";
		
		
	}
	
	//GRADES
	@GetMapping("/grades")
	public String listGrades(Model theModel) {
		theModel.addAttribute("grades", grades.findAll());
		return "grades";
		
	}
	@GetMapping("/grades/new")
	public String addGrades(Model theModel) {
		Grades theGrades = new Grades();
		theModel.addAttribute("grades", theGrades);
		return "add_grade";
		
	}
	
	@PostMapping("/grades")
	public String saveGrade(@ModelAttribute("grades") Grades theGrades, Model theModel) {
		grades.save(theGrades);
		return "redirect:/grades";
	}
	
	@RequestMapping("/grades/delete")
	public String deleteGrade(Model theModel) {
		grades.deleteAll();
		return "redirect:/grades";
		
		
	}
	

}
