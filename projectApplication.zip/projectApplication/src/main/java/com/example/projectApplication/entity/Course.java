package com.example.projectApplication.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name= "course")
public class Course {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private  Long id;
	
	@Column(name = "name")
	private String	name;
	
	@Column(name = "syllabus", length = 100)
	private String syllabus;

	@Column(name = "year")
	private Long year;
	
	@Column(name = "semester")
	private int semester;
	
	 @OneToMany(targetEntity= StudentRegistration.class, cascade = CascadeType.ALL)
	 @JoinColumn(name="course_fk", referencedColumnName = "id" )
	 private List<StudentRegistration> student_regs;
	
	public Course() {
		
	}
	

	public Course(String name, String syllabus, Long year, int semester) {
		super();
		this.name = name;
		this.syllabus = syllabus;
		this.year = year;
		this.semester = semester;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getSyllabus() {
		return syllabus;
	}


	public void setSyllabus(String syllabus) {
		this.syllabus = syllabus;
	}


	public Long getYear() {
		return year;
	}


	public void setYear(Long year) {
		this.year = year;
	}


	public int getSemester() {
		return semester;
	}


	public void setSemester(int semester) {
		this.semester = semester;
	}


	public List<StudentRegistration> getStudent_regs() {
		return student_regs;
	}


	public void setStudent_regs(List<StudentRegistration> student_regs) {
		this.student_regs = student_regs;
	}


	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", syllabus=" + syllabus + ", year=" + year + ", semester="
				+ semester + "]";
	}

	
	

}
