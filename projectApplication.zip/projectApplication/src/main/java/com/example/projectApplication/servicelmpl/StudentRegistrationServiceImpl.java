package com.example.projectApplication.servicelmpl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.projectApplication.dao.StudentRegistrationDAO;
import com.example.projectApplication.entity.StudentRegistration;
import com.example.projectApplication.service.StudentRegistrationService;
@Service
public class StudentRegistrationServiceImpl implements StudentRegistrationService {
	
	private StudentRegistrationDAO studentRegistrationDAO;

	public StudentRegistrationServiceImpl(StudentRegistrationDAO studentRegistrationDAO) {
		super();
		this.studentRegistrationDAO = studentRegistrationDAO;
	}

	@Override
	@Transactional
	public List<StudentRegistration> findAll() {
		
		return studentRegistrationDAO.findAll();
	}

	@Override
	@Transactional
	public StudentRegistration findRegistrationsByCourseId(Long id) {
	
		return studentRegistrationDAO.getById(id);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		studentRegistrationDAO.deleteById(id);
		
	}

	@Override
	@Transactional
	public StudentRegistration save(StudentRegistration studentRegistration) {
		return studentRegistrationDAO.save(studentRegistration);
	}

	@Override
	@Transactional
	public StudentRegistration update(StudentRegistration studentRegistration) {

		return studentRegistrationDAO.save(studentRegistration);
	}
	
	


	



}
