package com.example.projectApplication.service;

import java.util.List;

import com.example.projectApplication.entity.StudentRegistration;

public interface StudentRegistrationService {
	
	public List<StudentRegistration> findAll();
	
	public StudentRegistration findRegistrationsByCourseId(Long id);
	
	public void deleteById(Long id);
	
	public StudentRegistration save(StudentRegistration studentRegistration);
	
	public StudentRegistration update(StudentRegistration studentRegistration);



}
