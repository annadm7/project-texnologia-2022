package com.example.projectApplication.service;

import com.example.projectApplication.entity.Instructor;

public interface InstructorService  {
	
	Instructor save(Instructor instr);

}
